package Cuentas;

/**
 * Descripci�n de la clase: es la clase CCuenta y aqu� est�n los atributos.
 * @author Ruben Ramirez
 */
public class CCuenta {

    /**
    * @param nombre Es el nombre del titular
    * @param cuenta es el nombre de cuenta bancaria
    * @param saldo es el saldo actual de la cuenta
    * @param tipoInter�s es el porcentaje tipo de inter�s
    * 
    */
    private String nombre;
    private String cuenta;
    private double saldo;
    private double tipoInter�s;

    /**
     * Clase p�blica CCuenta
     */
    public CCuenta()
    {
    }

    /**
     * Clase p�blica CCuenta con las variables
     * @param nom es el valor que usaremos para nombre
     * @param cue es el valor que usaremos para cuenta
     * @param sal es el valor que usaremos para saldo
     * @param tipo es el valor del tipo de interes
     */
    public CCuenta(String nom, String cue, double sal, double tipo)
    {
        /**
         * @param nom es el valor que usaremos para nombre
         * @param cue es el valor que usaremos para cuenta
         * @param sal es el valor que usaremos para saldo
         */
        nombre =nom;
        cuenta=cue;
        saldo=sal;
    }

    /** Parametros de estado de cuenta
     * @return devuelve el saldo actual de la cuenta
     */
    public double estado()
    {
        return getSaldo();
    }
/**
 * Es el m�todo ingresar, con su cantidad y la excepci�n si es negativa
 * @param cantidad es la cantidad que se ingresa
 * @throws Exception es la excepci�n si es negativa
 */
    public void ingresar(double cantidad) throws Exception
    {
        /**
         * @throws Exception cuando se intente ingresar n�mero negativo
         */
        if (cantidad<0)
            throw new Exception("No se puede ingresar una cantidad negativa");
        setSaldo(getSaldo() + cantidad);
    }

    /**
     * Es el m�todo retirar, con su cantidad y la excepci�n si es negativa
     * @param cantidad es la cantidad que se retira
     * @throws Exception es la excepci�n si es negativa
     */
    public void retirar(double cantidad) throws Exception
    {
        /**
         * @throws Exception cuando se intente retirar n�mero negativo
         * @throws Exception cuando no hay saldo
         */
        if (cantidad <= 0)
            throw new Exception ("No se puede retirar una cantidad negativa");
        if (estado()< cantidad)
            throw new Exception ("No se hay suficiente saldo");
        setSaldo(getSaldo() - cantidad);
    }

    /** Parametros de nombre titular
     * @return el nombre del titular
     */
    public String getNombre() {
        return nombre;
    }

    /** Parametros para establecer nombre
     * @param nombre para establecer el nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /** Parametros para establecer la cuenta bancaria
     * @return la cuenta bancaria
     */
    public String getCuenta() {
        return cuenta;
    }

    /** Parametros para establecer la cuenta bancaria
     * @param cuenta para establecer la cuenta bancaria
     */
    public void setCuenta(String cuenta) {
        this.cuenta = cuenta;
    }

    /** Parametros para establecer saldo
     * @return el saldo actual
     */
    public double getSaldo() {
        return saldo;
    }

    /** Parametro para establecer saldo
     * @param saldo establecer el saldo
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    /** Parametro para ver tipo de interes
     * @return devuelve el porcentaje de tipoInter�s
     */
    public double getTipoInter�s() {
        return tipoInter�s;
    }

    /** Parametro para establecer interes
     * @param tipoInter�s establece el porcentaje de tipoInter�s 
     */
    public void setTipoInter�s(double tipoInter�s) {
        this.tipoInter�s = tipoInter�s;
    }
}
